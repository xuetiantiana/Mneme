<template>
  <div>
    <canvasComponent></canvasComponent>
  </div>
</template>

<script setup>
import { ref, watch, onMounted } from "vue";
import { useRouter, useRoute } from "vue-router";
import canvasComponent from "@/components/canvasComponent.vue";



</script>

<style lang="scss" scoped>

</style>